package com.example.mobileproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HomeActivity extends AppCompatActivity {

    public static final int REQUEST_PLAY_VIDEO = 1;
    private VideoModel videoData;
    private VideoDB videodb;
    private RecyclerView recyclerView;
    //private RecyclerView.Adapter videoAdapter;
    private List<VideoModel> videoList;
    private VideoAdapter videoAdapter;
    private LinearLayoutManager linearLayoutManager;
    ImageView logout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searchvideo);
        videodb = new VideoDB(HomeActivity.this);

//        videodb.deleteVideo("How2 tie a tie");
//        videodb.deleteVideo("How2 tie shoelace");
//        videodb.deleteVideo("Admin");
        //videodb.deleteVideo("How2 do Marlinspike Hitch");
        //videodb.deleteVideo("How2 do Marlinspike Knot");
        // videodb.deleteVideo("How2 open a box");
        // videodb.deleteVideo("how2 print hello world in java");
        if (videodb.getAllLocations().isEmpty()) {
            videodb.addVideo("Admin", "How2 tie a tie", "0qPU5hb-DcM");
            videodb.addVideo("Admin", "How2 tie shoelace", "Q5qZpQe_4EA");
            videodb.addVideo("Admin", "How2 make a slipknot", "OQ8zV1QAibs");
            videodb.addVideo("Admin", "How2 pick a lock", "QH1DIfXZRFk");
            videodb.addVideo("Admin", "How2 make a slime", "Cq3OqXuHyQY");


        }
        updateVideoView();
        ImageView addbtn = findViewById(R.id.addButton);
        addbtn.setOnClickListener(new View.OnClickListener() { //tTVl7uMt3pE
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(getApplicationContext(), AddNewVideo.class), REQUEST_PLAY_VIDEO);
//                Intent intent = new Intent(MainActivity.this, AddNewVideo.class);
//                //getIntent();
//
//                startActivity(intent);
            }
        });
        EditText inputSearch = findViewById(R.id.inputSearch);
        inputSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                videoAdapter.cancelTimer();
            }

            @Override
            public void afterTextChanged(Editable s) {
//                if (videoList.size() != 0) {
                videoAdapter.searchVideos(s.toString());
                //}
            }
        });
        logout = (ImageView) findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });


    }
    public void updateVideoView(){
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(false);
        linearLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        videoAdapter = new VideoAdapter(videodb.getAllLocations(), HomeActivity.this);
        recyclerView.setAdapter(videoAdapter);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_PLAY_VIDEO) {
            if (resultCode == Activity.RESULT_OK) {
                videoData = (VideoModel) data.getExtras().getSerializable("videoinput");
            }
        }
        //System.out.println("LOCATION ----> " + location.toString());

        if (videoData.getTitle() != null && videoData.getId() != -500) {
            System.out.println(videodb.addNewVideo(videoData));
        }

        updateVideoView();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);

        return  super.onCreateOptionsMenu(menu);

    }
}