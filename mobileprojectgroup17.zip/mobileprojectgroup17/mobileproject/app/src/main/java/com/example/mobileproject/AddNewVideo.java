package com.example.mobileproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class AddNewVideo extends AppCompatActivity {
    EditText inputTitle, inputName, inputVideo;
    VideoDB videodb;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_video);
        ImageView imageBack = findViewById(R.id.backButton);
        imageBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                VideoModel videoModel = new VideoModel(-500, "", "", "error");
                intent.putExtra("videoinput", videoModel);
                setResult(Activity.RESULT_OK, intent);
                finish();
            }
        });
//        imageBack.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });
        inputTitle = findViewById(R.id.titleInput);
        inputName = findViewById(R.id.nameInput);
        inputVideo = findViewById(R.id.videoidinput);

        ImageView imageSave = findViewById(R.id.doneButton);
        imageSave.setOnClickListener(v->saveVideo());
//        imageSave.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                saveVideo();
//
////                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
////                //intent.putExtra("video", videos);
////                setResult(Activity.RESULT_OK, intent);
////                finish();
//            }
//        });
    }
    private void saveVideo(){
        final String videoTitle = inputTitle.getText().toString().trim();
        final String videoName = inputName.getText().toString().trim();
        final String videoId = inputVideo.getText().toString().trim();
        VideoModel video = null;
        if (videoTitle.isEmpty()) {
            Toast.makeText(this, "Title can't be empty!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (videoId.isEmpty()) {
            Toast.makeText(this, "Video ID can't be empty!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (videoName.isEmpty()) {
            Toast.makeText(this, "User name can't be empty!", Toast.LENGTH_SHORT).show();
            return;
        }
        video = new VideoModel(-1, videoName, videoTitle, videoId);
//        long result = videodb.addVideo(videoName, videoTitle, videoId);
//        if (result>0){
//            Toast.makeText(this, "data Added", Toast.LENGTH_LONG).show();
//        }
        Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
        intent.putExtra("videoinput", video);
        setResult(Activity.RESULT_OK, intent);
        finish();
    }
}
