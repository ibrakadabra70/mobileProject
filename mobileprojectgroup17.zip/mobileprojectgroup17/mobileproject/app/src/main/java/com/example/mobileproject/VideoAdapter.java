package com.example.mobileproject;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.ViewHolder> {
    List<VideoModel> videos;
    Context context;
    List<VideoModel> videosource;
    private Timer timer;




    //OnItemClickListener listener;

    public VideoAdapter(List<VideoModel> videos, Context context) {
        this.videos = videos;
        this.context = context;
        videosource = videos;
        //this.listener = listener;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_card, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        com.example.mobileproject.VideoModel currentvideo = videos.get(position);
        String title = videos.get(position).getTitle();
        String name = "Added By: " + videos.get(position).getName();
        String videoid = videos.get(position).getVideoid();
        holder.title.setText(title);
        holder.name.setText(name);
        holder.videoid.setText(videoid);
        holder.youTubePlayerView.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
            @Override
            public void onReady(@NonNull YouTubePlayer youTubePlayer) {
                //String videoId = "0qPU5hb-DcM";
                youTubePlayer.cueVideo(videoid, 0);

            }
        });


    }

    @Override
    public int getItemCount() {
        return videos.size();
    }

    //public  com.example.youtubeview.VideoModel getVideoAt(int pos){return getItem(pos)}

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView name;
        TextView videoid;
        Button btnDelete;
        YouTubePlayerView youTubePlayerView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title_card_header);
            name = itemView.findViewById(R.id.name_card_header);
            videoid = itemView.findViewById(R.id.vidid_card_header);
            youTubePlayerView = itemView.findViewById(R.id.YotubeView1);

        }
    }
    public void searchVideos(final String searchKeyword) {
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (searchKeyword.trim().isEmpty()) {
                    videos = videosource;
                } else {
                    ArrayList<VideoModel> temp = new ArrayList<>();
                    for (VideoModel videotemp : videosource) {
                        if (videotemp.getTitle().toLowerCase().contains(searchKeyword.toLowerCase()) ||
                                videotemp.getName().toLowerCase().contains(searchKeyword.toLowerCase()) ||
                                videotemp.getVideoid().toLowerCase().contains(searchKeyword.toLowerCase())) {
                            temp.add(videotemp);
                        }
                    }
                    videos = temp;
                }

                new Handler(Looper.getMainLooper()).post(() -> notifyDataSetChanged());
            }
        }, 500);
    }


    public void cancelTimer() {
        if (timer != null) {
            timer.cancel();
        }
    }

}
