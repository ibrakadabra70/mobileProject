package com.example.mobileproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class VideoDB extends SQLiteOpenHelper {

    private static final String DB_NAME = "video.db";
    private static final String TABLE_NAME = "videos";
    private static final String ID = "id";
    private static final String NAME = "name";
    private static final String TITLE = "title";
    private static final String VIDEOID = "videoid";

    public VideoDB(Context context) {
        super(context, DB_NAME, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "create table " + TABLE_NAME + " (" +
                        ID + " integer primary key autoincrement, " +
                        NAME + " text not null, " +
                        TITLE + " text not null, " +
                        VIDEOID + " text not null" +
                        ");"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + TABLE_NAME);
        onCreate(db);
    }

    public long addVideo(String name, String title, String videoid){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues addContent = new ContentValues();
        addContent.put(NAME, name);//parse the value of the address
        addContent.put(TITLE, title);//value of latitude
        addContent.put(VIDEOID, videoid);//value of longitude

        long add = db.insert(TABLE_NAME, null, addContent);//insert method for inserting to database
        return add;
    }
    public boolean addNewVideo(com.example.mobileproject.VideoModel video) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NAME, video.getName());
        values.put(TITLE, video.getTitle());
        values.put(VIDEOID, video.getVideoid());

        long insertStatus = db.insert(TABLE_NAME, null, values);

        if (insertStatus == -1) {
            return false;
        }

        return true;
    }
    public Cursor playVideo(String title){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM" + TABLE_NAME + "WHERE" + TITLE + "='"+title+"'";
        Cursor data = db.rawQuery(query, null);
        return data;
//        ContentValues values = new ContentValues();
//        values.put(NAME, videoModel.getName());
//        values.put(TITLE, videoModel.getTitle());
//        values.put(VIDEOID, videoModel.getVideoid());
        //long playStatus = db.insert()
        //return true;
    }
    public int deleteVideo(String title){
        SQLiteDatabase db = this.getWritableDatabase();
        int delete = db.delete(TABLE_NAME, TITLE+"=?", new String[]{title});
        return delete;
    }
    public List<com.example.mobileproject.VideoModel> getAllLocations() {
        List<com.example.mobileproject.VideoModel> result = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        String query = "select * from " + TABLE_NAME;

        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                String title = cursor.getString(2);
                String videoid = cursor.getString(3);


                com.example.mobileproject.VideoModel location = new com.example.mobileproject.VideoModel(id, name, title, videoid);
                result.add(location);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return result;
    }
}
